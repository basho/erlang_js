(function() {
  for (a = 0; a < 2; a++)
    ''.watch("", function() {})
})()
