//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by XPCIDispatchTest.rc
//
#define IDS_PROJNAME                    100
#define IDS_NSXPCDISPTTESTMETHODS_DESC  101
#define IDR_nsXPCDisptTestMethods       102
#define IDS_NSXPCDISPTESTMETHODS_DESC   103
#define IDR_nsXPCDispTestMethods        104
#define IDS_NSXPCDISPSIMPLE_DESC        105
#define IDR_nsXPCDispSimple             106
#define IDS_NSXPCDISPTESTNOIDISPATCH_DESC 107
#define IDR_nsXPCDispTestNoIDispatch    108
#define IDS_NSXPCDISPTESTNOSCRIPT_DESC  109
#define IDR_nsXPCDispTestNoScript       110
#define IDS_NSXPCDISPTESTPROPERTIES_DESC 111
#define IDR_nsXPCDispTestProperties     112
#define IDS_NSXPCDISPTESTARRAYS_DESC    113
#define IDR_nsXPCDispTestArrays         114
#define IDS_NSXPCDISPTESTSCRIPTON_DESC  115
#define IDR_nsXPCDispTestScriptOn       116
#define IDS_NSXPCDISPTESTSCRIPTOFF_DESC 117
#define IDR_nsXPCDispTestScriptOff      118
#define IDS_NSXPCDISPTESTWRAPPEDJS_DESC 119
#define IDR_nsXPCDispTestWrappedJS      120

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        204
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         201
#define _APS_NEXT_SYMED_VALUE           121
#endif
#endif
